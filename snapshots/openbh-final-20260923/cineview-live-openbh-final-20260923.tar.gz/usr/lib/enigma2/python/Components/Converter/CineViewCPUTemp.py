# -*- coding: utf-8 -*-
from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached
import os, glob

class CineViewCPUTemp(Poll, Converter):
    PATHS = (
        '/sys/class/thermal/thermal_zone0/temp',
        '/sys/class/thermal/thermal_zone1/temp',
        '/proc/hisi/msp/pm_cpu',
        '/proc/stb/sensors/temp0/value',
        '/proc/stb/fp/temp_sensor',
        '/proc/stb/sensors/temp',
    )
    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.type = type
        self.poll_interval = 5000
        self.poll_enabled = True
    def _candidates(self):
        paths=list(self.PATHS)
        paths += sorted(glob.glob('/sys/class/thermal/thermal_zone*/temp'))
        paths += sorted(glob.glob('/proc/stb/sensors/*temp*'))
        seen=set()
        for p in paths:
            if p not in seen:
                seen.add(p); yield p
    def _read(self):
        for path in self._candidates():
            try:
                if not os.path.isfile(path): continue
                raw=open(path,'r').read().strip().replace('C','').replace('c','')
                if not raw: continue
                val=float(raw.split()[0])
                if val > 100000: val /= 1000.0
                elif val > 1000: val /= 1000.0
                if 0 < val < 150: return int(round(val))
            except Exception:
                pass
        return None
    @cached
    def getText(self):
        v=self._read()
        if v is None: return 'CPU: --°C'
        return 'CPU: %d°C' % v
    text=property(getText)


#!/usr/bin/env python3
from __future__ import print_function
import re, sys

path = sys.argv[1]
data = open(path, 'r', encoding='utf-8', errors='ignore').read()

def patch_screen(data, name, fn):
    pat = re.compile(r'(<screen\b(?=[^>]*\bname=["\']%s["\'])[^>]*>)(.*?)(</screen>)' % re.escape(name), re.S)
    m = pat.search(data)
    if not m:
        return data
    body = fn(m.group(2))
    return data[:m.start()] + m.group(1) + body + m.group(3) + data[m.end():]

def infobar_body(body):
    body = body.replace('position="24,842" size="1872,236"', 'position="16,842" size="1888,236"')
    body = body.replace('position="24,842" size="1872,2"', 'position="16,842" size="1888,2"')
    body = body.replace('position="24,1076" size="1872,2"', 'position="16,1076" size="1888,2"')
    body = body.replace('position="24,842" size="2,236"', 'position="16,842" size="2,236"')
    body = body.replace('position="1894,842" size="2,236"', 'position="1902,842" size="2,236"')
    body = body.replace('position="36,1016" size="1848,2"', 'position="28,1016" size="1864,2"')
    return body

def second_body(body):
    body = infobar_body(body)
    body = body.replace('position="70,145" size="790,440"', 'position="55,145" size="805,440"')
    body = body.replace('position="925,145" size="925,440"', 'position="925,145" size="940,440"')
    def add_border(m):
        tag=m.group(0)
        if 'borderWidth=' not in tag:
            tag=tag[:-2] + ' borderWidth="2" borderColor="#00303030" />'
        return tag
    body = re.sub(r'<widget\b(?=[^>]*\brender=["\']PosterX["\'])[^>]*/>', add_border, body)
    return body

data = patch_screen(data, 'InfoBar', infobar_body)
data = patch_screen(data, 'SecondInfoBar', second_body)

open(path, 'w', encoding='utf-8').write(data)
print('openvix-final-ok')

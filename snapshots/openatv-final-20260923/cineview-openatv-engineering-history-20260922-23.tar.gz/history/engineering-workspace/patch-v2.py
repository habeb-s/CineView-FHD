import re,sys,xml.etree.ElementTree as ET
p=sys.argv[1]; s=open(p,encoding='utf-8').read()
def sre(name): return re.compile(r'<screen\b(?=[^>]*\bname=["\']'+re.escape(name)+r'["\'])[^>]*>.*?</screen>',re.S)
# TaskView: exact OpenATV 8 component contract, CineView FHD geometry.
task='''<screen name="TaskView" title="Task View" position="fill" flags="wfNoBorder">
    <panel name="PigTemplate"/>
    <widget source="Title" render="Label" position="780,45" size="1110,48" font="Regular;34" foregroundColor="secondFG" transparent="1"/>
    <widget source="name" render="Label" position="780,120" size="1110,55" font="Regular;34" foregroundColor="foreground" transparent="1"/>
    <widget source="task" render="Label" position="780,185" size="1110,48" font="Regular;29" foregroundColor="grey" transparent="1"/>
    <widget source="progress" render="Progress" position="780,265" size="1110,48" borderWidth="2" backgroundColor="un33333a"/>
    <widget source="progress" render="Label" position="780,267" size="1110,44" font="Regular;31" foregroundColor="foreground" halign="center" valign="center" transparent="1" zPosition="2"><convert type="ProgressToText"/></widget>
    <widget source="status" render="Label" position="780,340" size="1110,48" font="Regular;29" transparent="1"/>
    <widget name="config" position="780,420" size="1110,150" itemHeight="52" font="Regular;29" scrollbarMode="showOnDemand"/>
    <panel name="ButtonTemplate"/>
</screen>'''
if not sre('TaskView').search(s):
    m=sre('JobView').search(s)
    if m: s=s[:m.start()]+task+'\n\n'+s[m.start():]
# Legacy JobView remains for older plugins but stays inside FHD bounds.
s=s.replace('position="1550,1030" size="540,38"','position="1550,1030" size="340,38"')
# HelpMenu: OpenATV 8 current contract (list/description/buttonlist/rc/label/indicatorU/L).
m=sre('HelpMenu').search(s)
if m:
    old=m.group(0)
    lm=re.search(r'<widget source="list".*?</widget>',old,re.S)
    listxml=lm.group(0) if lm else '<widget source="list" render="Listbox" position="30,100" size="1100,850" scrollbarMode="showOnDemand"/>'
    listxml=re.sub(r'\sconditional="indicatorU0"','',listxml)
    listxml=re.sub(r'position="[^"]+"','position="30,105"',listxml,count=1)
    listxml=re.sub(r'size="[^"]+"','size="1100,850"',listxml,count=1)
    inds=[]
    for i in range(16):
        for side in ('U','L'):
            inds.append('    <widget name="indicator%s%d" pixmap="yellow_circle23x23.png" position="1450,330" size="23,23" zPosition="20" alphatest="blend"/>'%(side,i))
    helpxml='''<screen name="HelpMenu" title="Help" position="fill" flags="wfNoBorder">
    <panel name="PigLessTemplate"/>
    <widget source="Title" render="Label" position="30,25" size="1830,55" font="Regular;38" foregroundColor="secondFG" transparent="1"/>
    %s
    <widget name="description" position="1165,115" size="695,125" font="Regular;27" foregroundColor="foreground" transparent="1" valign="top"/>
    <widget name="buttonlist" position="1165,250" size="695,80" font="Regular;24" foregroundColor="yellow" transparent="1" valign="top"/>
    <widget name="rc" position="1450,330" size="154,500" zPosition="10" alphatest="blend" transparent="1"/>
    <widget name="label" position="1165,850" size="695,80" font="Regular;23" foregroundColor="secondFG" transparent="1" halign="center" valign="center"/>
%s
    <widget source="key_help" render="Label" position="1690,980" size="170,45" font="Regular;24" foregroundColor="secondFG" halign="center" valign="center" transparent="1"><convert type="ConditionalShowHide"/></widget>
</screen>'''%(listxml,'\n'.join(inds))
    s=s[:m.start()]+helpxml+s[m.end():]
# Network values were 20px outside the 1920 canvas.
s=s.replace('source="DNS1" render="Label" position="1640,675" size="300,37"','source="DNS1" render="Label" position="1640,675" size="250,37"')
s=s.replace('source="DNS2" render="Label" position="1640,720" size="300,37"','source="DNS2" render="Label" position="1640,720" size="250,37"')
# Custom standby streaming area: keep it on canvas.
s=s.replace('source="session.CurrentService" render="Label" position="450,250" size="1620,800"','source="session.CurrentService" render="Label" position="450,250" size="1420,800"')
# CineView already carries the MediaPlayer fallback under dvr/.
s=s.replace('pixmap="icons/no_coverArt.png"','pixmap="dvr/no_coverArt.png"')
ET.fromstring(s)
open(p,'w',encoding='utf-8').write(s)

import sys,re,xml.etree.ElementTree as E
p,n=sys.argv[1:]; s=open(p,encoding='utf-8').read(); E.parse(p)
def block(name):
    m=re.search(r'<screen\b(?=[^>]*name="'+re.escape(name)+r'")[^>]*>.*?</screen>',s,re.S)
    return m.group(0) if m else ''
checks={
'TaskView':bool(block('TaskView')),
'HelpMenu':all(x in block('HelpMenu') for x in ['buttonlist','indicatorU0','indicatorL15']),
'Vert':all(('source="piconCh%d"'%i) in block('EPGvertical') for i in range(1,6)),
'Timeline':all(('name="timeline%d"'%i) in block('GraphicalEPG') for i in range(6)),
'SkinSelection':'size="1080,610"' in block('SkinSelection'),
'PluginAspect':'BT_KEEP_ASPECT_RATIO' in s,
}
print(n,checks)
if not all(checks.values()): raise SystemExit(3)

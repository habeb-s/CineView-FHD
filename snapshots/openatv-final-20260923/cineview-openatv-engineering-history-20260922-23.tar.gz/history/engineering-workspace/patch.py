import re,sys,xml.etree.ElementTree as ET
p=sys.argv[1]
s=open(p,encoding='utf-8').read()
# 1) OpenATV PluginBrowser list: preserve icon aspect ratio like native grid mode.
s=s.replace('MultiContentEntryPixmapAlphaBlend(pos=(12, 4), size=(185, 80), png=3, flags=BT_SCALE),','MultiContentEntryPixmapAlphaBlend(pos=(12, 4), size=(185, 80), png=3, flags=BT_SCALE | BT_KEEP_ASPECT_RATIO | BT_HALIGN_CENTER | BT_VALIGN_CENTER),')
# Helpers
screen_re=lambda name: re.compile(r'(<screen\b(?=[^>]*\bname=["\']'+re.escape(name)+r'["\'])[^>]*>)(.*?)(</screen>)',re.S)
# 2) Graphical EPG families: skin all timeline controls OpenATV creates.
def add_timelines(name, y, h):
    global s
    pat=screen_re(name)
    m=pat.search(s)
    if not m: return
    body=m.group(2)
    if 'name="timeline0"' not in body:
        block='\n'.join('        <widget name="timeline%d" pixmap="window/timeline.png" position="0,%d" size="1,%d" zPosition="22"/>'%(i,y,h) for i in range(6))
        marker=re.search(r'\s*<widget name="timeline_now"[^>]*/>',body)
        if marker:
            body=body[:marker.start()]+'\n'+block+'\n'+body[marker.start():]
    # ensure the now marker uses CineView/OpenATV native timeline asset when skinned.
    body=re.sub(r'<widget name="timeline_now"([^>]*?)position="[^"]+"([^>]*?)/>', lambda mm:'<widget name="timeline_now"'+mm.group(1)+'position="6,%d"'%y+mm.group(2)+' pixmap="window/timeline-now.png" alphatest="blend"/>', body, count=1)
    s=s[:m.start()]+m.group(1)+body+m.group(3)+s[m.end():]
add_timelines('GraphicalEPG',385,545)
add_timelines('GraphicalEPGPIG',380,365)
add_timelines('GraphicalInfoBarEPG',112,143)
# 3) Vertical EPG: OpenATV 8 actively updates piconCh1..5 and Active1..5.
def patch_vertical(name):
    global s
    pat=screen_re(name); m=pat.search(s)
    if not m: return
    body=m.group(2)
    xs=[45,385,725,1065,1405]
    if 'source="piconCh1"' not in body:
        block=[]
        for i,x in enumerate(xs,1):
            block.append('        <widget name="Active%d" position="%d,95" size="330,42" backgroundColor="selectedBG" transparent="0" zPosition="2"/>'%(i,x))
            block.append('        <widget source="piconCh%d" render="Picon" position="%d,95" size="70,42" zPosition="4" alphatest="blend" transparent="1"><convert type="ServiceName">Reference</convert></widget>'%(i,x+5))
        marker=re.search(r'\s*<widget name="currCh1"',body)
        if marker: body=body[:marker.start()]+'\n'+'\n'.join(block)+'\n'+body[marker.start():]
    # Give channel text its own area beside picon instead of drawing through it.
    for i,x in enumerate(xs,1):
        body=re.sub(r'<widget name="currCh%d"[^>]*/>'%i,'<widget name="currCh%d" position="%d,95" size="248,42" font="Regular;27" foregroundColor="secondFG" transparent="1" zPosition="5"/>'%(i,x+82),body,count=1)
    s=s[:m.start()]+m.group(1)+body+m.group(3)+s[m.end():]
patch_vertical('EPGvertical')
patch_vertical('EPGverticalPIG')
# 4) SkinSelection: use full OpenATV Setup contract while keeping buttons clear.
pat=screen_re('SkinSelection'); m=pat.search(s)
if m:
    body=m.group(2)
    body=re.sub(r'<widget name="config"[^>]*/>','<widget name="config" position="780,120" size="1080,610" itemHeight="58" font="Regular;30" transparent="1" enableWrapAround="1" scrollbarMode="showOnDemand" zPosition="3"/>',body,count=1)
    body=re.sub(r'<widget name="description"[^>]*/>','<widget name="description" position="780,748" size="1080,110" font="Regular;25" foregroundColor="foreground" transparent="1" valign="top" zPosition="3"/>',body,count=1)
    body=re.sub(r'<widget name="footnote"[^>]*/>','<widget name="footnote" position="780,868" size="1080,55" font="Regular;22" foregroundColor="secondFG" transparent="1" valign="top" zPosition="3"/>',body,count=1)
    s=s[:m.start()]+m.group(1)+body+m.group(3)+s[m.end():]
ET.fromstring(s)
open(p,'w',encoding='utf-8').write(s)

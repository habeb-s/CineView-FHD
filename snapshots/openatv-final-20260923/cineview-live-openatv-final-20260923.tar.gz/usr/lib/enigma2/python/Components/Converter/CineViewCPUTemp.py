# -*- coding: utf-8 -*-
from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached
import os

class CineViewCPUTemp(Poll, Converter):
    PATHS = (
        '/sys/class/thermal/thermal_zone0/temp',
        '/proc/stb/sensors/temp0/value',
        '/proc/stb/fp/temp_sensor',
    )
    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.type = type
        self.poll_interval = 5000
        self.poll_enabled = True
    def _read(self):
        for path in self.PATHS:
            try:
                if os.path.exists(path):
                    raw=open(path,'r').read().strip()
                    val=float(raw)
                    if val > 1000: val /= 1000.0
                    if 0 < val < 150: return int(round(val))
            except Exception:
                pass
        return None
    @cached
    def getText(self):
        v=self._read()
        if v is None: return 'CPU: --°C'
        return 'CPU: %d°C' % v
    text=property(getText)

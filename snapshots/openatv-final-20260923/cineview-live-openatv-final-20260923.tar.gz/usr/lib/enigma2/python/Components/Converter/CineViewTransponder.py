# -*- coding: utf-8 -*-
from __future__ import print_function

from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached


class CineViewTransponder(Poll, Converter):
    """Small image-neutral transponder/orbital fallback for CineView."""
    POL = {0: 'H', 1: 'V', 2: 'L', 3: 'R'}

    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.mode = (type or 'Info').lower()
        self.poll_interval = 1500
        self.poll_enabled = True

    def _service(self):
        try:
            s = getattr(self.source, 'service', None)
            if callable(s):
                s = s()
            return s
        except Exception:
            return None

    def _data(self):
        s = self._service()
        if s is None:
            return {}
        try:
            fe = s.frontendInfo()
            if fe:
                d = fe.getAll(True)
                if isinstance(d, dict):
                    return d
        except Exception:
            pass
        return {}

    def _orbital(self, d):
        try:
            pos = int(d.get('orbital_position', d.get('orbital position', 0)) or 0)
            if not pos:
                return ''
            if pos > 1800:
                return '%.1f°W' % ((3600 - pos) / 10.0)
            return '%.1f°E' % (pos / 10.0)
        except Exception:
            return ''

    @cached
    def getText(self):
        d = self._data()
        if self.mode in ('orbital', 'position'):
            return self._orbital(d)
        try:
            system = str(d.get('system', d.get('tuner_type', '')) or '')
            freq = int(d.get('frequency', 0) or 0)
            if freq > 100000:
                freq = int(round(freq / 1000.0))
            sr = int(d.get('symbol_rate', d.get('symbol rate', 0)) or 0)
            if sr > 100000:
                sr = int(round(sr / 1000.0))
            pol = d.get('polarization_abbreviation', '') or d.get('polarization', '')
            if isinstance(pol, int):
                pol = self.POL.get(pol, str(pol))
            fec = str(d.get('fec_inner', d.get('fec', '')) or '')
            mod = str(d.get('modulation', '') or '')
            parts = []
            if system: parts.append(system)
            if freq: parts.append('%d MHz' % freq)
            if pol != '': parts.append(str(pol))
            if sr: parts.append(str(sr))
            if fec and fec not in ('0', 'None', 'Auto', 'AUTO'): parts.append(fec)
            if mod and mod not in ('0', 'None', 'Auto', 'AUTO'): parts.append(mod)
            orb = self._orbital(d)
            if orb: parts.append(orb)
            return ' '.join(parts)
        except Exception:
            return ''

    text = property(getText)

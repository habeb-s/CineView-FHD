# -*- coding: utf-8 -*-
from __future__ import print_function
import os
import re
import time

from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached
from Components.config import config, ConfigSubsection, ConfigSelection


def ensure_config():
    if not hasattr(config.plugins, "cineview"):
        config.plugins.cineview = ConfigSubsection()
    if not hasattr(config.plugins.cineview, "servermode"):
        config.plugins.cineview.servermode = ConfigSelection(default="profile", choices=[
            ("full", "Full server details"),
            ("profile", "EMU + subscription only"),
            ("hide", "Hide server information"),
        ])


ensure_config()


class CineViewCamInfo(Poll, Converter):
    CAM_NAMES = ("oscam", "ncam", "cccam", "mgcamd", "gcam", "wicard", "camd3", "newcs", "evocamd")

    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.poll_interval = 1500
        self.poll_enabled = True
        self._cam = ""
        self._cam_ts = 0

    def camName(self):
        now = time.time()
        if now - self._cam_ts < 5 and self._cam:
            return self._cam
        found = ""
        try:
            for pid in os.listdir("/proc"):
                if not pid.isdigit():
                    continue
                try:
                    with open("/proc/%s/comm" % pid, "r") as f:
                        name = f.read().strip()
                    low = name.lower()
                    if any(x in low for x in self.CAM_NAMES):
                        found = name
                        break
                except Exception:
                    pass
        except Exception:
            pass
        if not found:
            # Best-effort fallback from settings.
            try:
                with open("/etc/enigma2/settings", "r") as f:
                    for line in f:
                        if "softcam" in line.lower() and "=" in line:
                            val = line.split("=", 1)[1].strip()
                            if val:
                                found = val
                                break
            except Exception:
                pass
        self._cam = found or "CAM"
        self._cam_ts = now
        return self._cam

    def readEcm(self):
        data = {}
        for path in ("/tmp/ecm.info", "/tmp/ecm0.info", "/tmp/ecm1.info"):
            if not os.path.exists(path):
                continue
            try:
                with open(path, "r") as f:
                    for raw in f:
                        line = raw.strip()
                        if not line:
                            continue
                        if ":" in line:
                            k, v = line.split(":", 1)
                        elif "=" in line:
                            k, v = line.split("=", 1)
                        else:
                            continue
                        data[k.strip().lower()] = v.strip()
                if data:
                    break
            except Exception:
                pass
        return data

    def first(self, data, keys):
        for k in keys:
            v = data.get(k, "").strip()
            if v:
                return v
        return ""

    @cached
    def getText(self):
        ensure_config()
        mode = config.plugins.cineview.servermode.value
        if mode == "hide":
            return ""
        d = self.readEcm()
        cam = self.camName()
        reader = self.first(d, ("reader", "label", "profile", "account", "user", "using"))
        server = self.first(d, ("server", "address", "from", "source", "hostname", "host"))
        port = self.first(d, ("port",))

        # Avoid duplicating the port if the server already includes one.
        if server and port and not re.search(r":\d+$", server):
            server = "%s:%s" % (server, port)

        lines = [cam]
        if reader:
            lines.append("Reader: %s" % reader)
        elif d.get("using"):
            lines.append("Using: %s" % d.get("using"))
        if mode == "full" and server:
            lines.append("Server: %s" % server)
        return "\n".join(lines)

    text = property(getText)

# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import re
import threading
import time

from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached
from Components.config import config


class CineViewIMDb(Poll, Converter):
    """Small non-blocking IMDb rating converter.

    Uses the same public IMDb GraphQL endpoint and ratingsSummary.aggregateRating
    field as the installed official Plugins/Extensions/IMDb plugin.  Network work
    stays off the Enigma2 UI thread and results are cached for six hours.
    """

    CACHE = {}
    PENDING = set()
    LOCK = threading.Lock()
    TTL = 21600

    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.mode = (type or 'plain').lower()
        self.poll_interval = 1500
        self.poll_enabled = True

    @classmethod
    def clean_title(cls, title):
        text = (title or '').replace('\x86', '').replace('\x87', '').strip()
        try:
            if hasattr(config.plugins, 'imdb') and hasattr(config.plugins.imdb, 'ignore_tags'):
                for tag in config.plugins.imdb.ignore_tags.value.split(','):
                    tag = tag.strip()
                    if tag:
                        text = text.replace(tag, '')
        except Exception:
            pass
        # Only strip obvious broadcast episode suffixes; do not over-clean titles.
        text = re.sub(r'(?i)\s*[\[(]?(?:odc\.?|ep\.?|episode|seria|sezon)\s*\d+[^\])]*[\])]?\s*$', '', text).strip(' -:')
        return ' '.join(text.split()) or (title or '').strip()

    @classmethod
    def headers(cls):
        h = {'content-type': 'application/json', 'referer': 'https://www.imdb.com/'}
        try:
            from Components.Language import language
            lang = language.getLanguage().replace('_', '-')
            if lang:
                h['X-Imdb-User-Language'] = lang
                if '-' in lang:
                    h['X-Imdb-User-Country'] = lang.split('-', 1)[1]
        except Exception:
            pass
        return h

    @classmethod
    def post_graphql(cls, query):
        import requests
        return requests.post(
            'https://caching.graphql.imdb.com/',
            data=json.dumps({'query': query}),
            headers=cls.headers(),
            timeout=(2.5, 5.0)
        )

    @classmethod
    def search_query(cls, title):
        q = json.dumps(title)
        return '''
query Search {
  mainSearch(
    first: 10
    options: {
      searchTerm: %s
      type: TITLE
      includeAdult: true
      isExactMatch: false
      titleSearchOptions: { type: [MOVIE, TV, TV_EPISODE] }
    }
  ) {
    edges {
      node {
        entity {
          ... on Title {
            id
            titleText { text }
            originalTitleText { text }
            releaseYear { year }
          }
        }
      }
    }
  }
}
''' % q

    @classmethod
    def rating_query(cls, title_id):
        tid = json.dumps(title_id)
        return '''
query TitleStoryline {
  title(id: %s) {
    id
    ratingsSummary {
      aggregateRating
      voteCount
    }
  }
}
''' % tid

    @staticmethod
    def norm(text):
        try:
            text = text.casefold()
        except Exception:
            text = (text or '').lower()
        return re.sub(r'[^\w]+', '', text or '', flags=re.UNICODE)

    @classmethod
    def pick_title_id(cls, payload, wanted):
        edges = (((payload or {}).get('data') or {}).get('mainSearch') or {}).get('edges') or []
        wn = cls.norm(wanted)
        fallback = None
        for edge in edges:
            ent = (((edge or {}).get('node') or {}).get('entity') or {})
            tid = ent.get('id')
            if not tid:
                continue
            if fallback is None:
                fallback = tid
            names = []
            for k in ('titleText', 'originalTitleText'):
                val = (ent.get(k) or {}).get('text')
                if val:
                    names.append(val)
            if any(cls.norm(n) == wn for n in names):
                return tid
        return fallback

    @classmethod
    def worker(cls, original_title):
        rating = None
        try:
            title = cls.clean_title(original_title)
            r = cls.post_graphql(cls.search_query(title))
            if r.ok:
                tid = cls.pick_title_id(r.json(), title)
                if tid:
                    d = cls.post_graphql(cls.rating_query(tid))
                    if d.ok:
                        rs = ((((d.json() or {}).get('data') or {}).get('title') or {}).get('ratingsSummary') or {})
                        v = rs.get('aggregateRating')
                        if v is not None:
                            rating = float(v)
        except Exception:
            rating = None
        with cls.LOCK:
            cls.CACHE[original_title] = (rating, time.time())
            cls.PENDING.discard(original_title)

    def title(self):
        try:
            ev = getattr(self.source, 'event', None)
            return (ev.getEventName() if ev else '') or ''
        except Exception:
            return ''

    def rating(self, title):
        now = time.time()
        with self.LOCK:
            item = self.CACHE.get(title)
            if item and now - item[1] < self.TTL:
                return item[0]
            if title and title not in self.PENDING:
                self.PENDING.add(title)
                try:
                    t = threading.Thread(target=self.worker, args=(title,))
                    t.daemon = True
                    t.start()
                except Exception:
                    self.PENDING.discard(title)
            return item[0] if item else None

    @cached
    def getText(self):
        title = self.title().strip()
        if not title:
            return '--'
        rating = self.rating(title)
        if rating is None:
            return '--'
        if self.mode == 'stars':
            n = max(0, min(5, int(round(rating / 2.0))))
            return ('★' * n) + ('☆' * (5 - n))
        if self.mode in ('label', 'imdb'):
            return 'IMDb %.1f/10' % rating
        return '%.1f/10' % rating

    text = property(getText)

# -*- coding: utf-8 -*-
from __future__ import print_function

from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached
from enigma import eConsoleAppContainer, iServiceInformation
import NavigationInstance


class _BitrateSetupEngine(object):
    """Shared reader using the exact `bitrate` executable used by Bitrate Setup."""
    def __init__(self):
        self.container = eConsoleAppContainer()
        self.container.appClosed.append(self._closed)
        self.container.dataAvail.append(self._data)
        self.remaining = ""
        self.lines = []
        self.running = False
        self.service_key = None
        self.vmin = self.vmax = self.vavg = self.vcur = 0
        self.amin = self.amax = self.aavg = self.acur = 0

    def _clear_values(self):
        self.vmin = self.vmax = self.vavg = self.vcur = 0
        self.amin = self.amax = self.aavg = self.acur = 0

    def stop(self):
        if self.running:
            try:
                self.container.kill()
            except Exception:
                pass
        self.running = False
        self.remaining = ""
        self.lines = []
        self._clear_values()

    def _closed(self, retval):
        self.running = False
        self.remaining = ""
        self.lines = []

    def _data(self, data):
        try:
            if isinstance(data, bytes):
                data = data.decode('utf-8', 'ignore')
        except Exception:
            data = str(data)
        data = self.remaining + data
        parts = data.split('\n')
        if parts and parts[-1]:
            self.remaining = parts[-1]
            parts = parts[:-1]
        else:
            self.remaining = ""
        for line in parts:
            line = line.strip()
            if line:
                self.lines.append(line)
        while len(self.lines) >= 2:
            vline = self.lines.pop(0)
            aline = self.lines.pop(0)
            try:
                v = vline.split()
                a = aline.split()
                if len(v) >= 4 and len(a) >= 4:
                    self.vmin, self.vmax, self.vavg, self.vcur = [int(float(x)) for x in v[:4]]
                    self.amin, self.amax, self.aavg, self.acur = [int(float(x)) for x in a[:4]]
            except Exception:
                self._clear_values()

    def ensure(self):
        try:
            nav = NavigationInstance.instance
            if nav is None:
                return
            service = nav.getCurrentService()
            ref = nav.getCurrentlyPlayingServiceReference()
            if service is None or ref is None:
                return
            key = ref.toString()
            if self.running and key == self.service_key:
                return
            if key != self.service_key:
                self.stop()
            self.service_key = key

            adapter = 0
            demux = 0
            try:
                stream = service.stream()
                if stream:
                    streamdata = stream.getStreamingData()
                    if streamdata:
                        adapter = int(streamdata.get('adapter', 0) or 0)
                        demux = int(streamdata.get('demux', 0) or 0)
            except Exception:
                adapter = 0
                demux = 0

            info = service.info()
            if info is None:
                return
            vpid = info.getInfo(iServiceInformation.sVideoPID)
            apid = info.getInfo(iServiceInformation.sAudioPID)
            if vpid is None or vpid < 0:
                vpid = 0
            if apid is None or apid < 0:
                apid = 0
            if not vpid and not apid:
                return

            # This is intentionally identical to Plugins/Extensions/Bitrate/bitrate.py
            cmd = "bitrate %d %d %d %d" % (adapter, demux, vpid, apid)
            self.remaining = ""
            self.lines = []
            self._clear_values()
            self.running = True
            rc = self.container.execute(cmd)
            if rc:
                self.running = False
        except Exception:
            self.running = False


_ENGINE = _BitrateSetupEngine()


class CineViewBitrate(Poll, Converter):
    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.mode = (type or 'Mbps').lower()
        self.poll_interval = 1000
        self.poll_enabled = True

    @cached
    def getText(self):
        _ENGINE.ensure()
        if self.mode in ('video', 'v'):
            return ("%d kbit/s" % _ENGINE.vcur) if _ENGINE.vcur else "..."
        if self.mode in ('audio', 'a'):
            return ("%d kbit/s" % _ENGINE.acur) if _ENGINE.acur else "..."
        if self.mode in ('details', 'va'):
            if _ENGINE.vcur or _ENGINE.acur:
                return "V:%d  A:%d kbit/s" % (_ENGINE.vcur, _ENGINE.acur)
            return "..."
        total = _ENGINE.vcur + _ENGINE.acur
        return ("%.2f Mbps" % (float(total) / 1000.0)) if total else "..."

    text = property(getText)

    def changed(self, what):
        Converter.changed(self, what)

# -*- coding: utf-8 -*-
from __future__ import print_function
import os, shutil
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection, getConfigListEntry, configfile
from Components.ActionMap import ActionMap
from Components.Label import Label
from .theme import THEMES, apply_theme

VERSION='2.0'
SKIN_DIR='/usr/share/enigma2/CineView_FHD'
ACTIVE=os.path.join(SKIN_DIR,'skin.xml')
POSTERX='/usr/lib/enigma2/python/Components/Renderer/CineViewPosterX.py'
OA_SOURCE='/usr/lib/enigma2/python/Components/Sources/OAWeather.py'
MSN_SOURCE='/usr/lib/enigma2/python/Components/Sources/MSNWeather.py'
CPU_SENSOR='/sys/class/thermal/thermal_zone0/temp'
ICON='/usr/lib/enigma2/python/Plugins/Extensions/CineViewControl/plugin.png'
SMARTDEPS='/usr/lib/enigma2/python/Plugins/Extensions/CineViewControl/smartdeps.sh'
SMARTLOG='/tmp/cineview-smartdeps.log'

def exists_py(base): return os.path.exists(base) or os.path.exists(base+'c') or os.path.exists(base+'o')

def ensure_config():
    if not hasattr(config.plugins,'cineview'): config.plugins.cineview=ConfigSubsection()
    if not hasattr(config.plugins.cineview,'poster_infobar'): config.plugins.cineview.poster_infobar=ConfigYesNo(default=True)
    if not hasattr(config.plugins.cineview,'poster_second'): config.plugins.cineview.poster_second=ConfigYesNo(default=True)
    if not hasattr(config.plugins.cineview,'poster_channels'): config.plugins.cineview.poster_channels=ConfigYesNo(default=True)
    if not hasattr(config.plugins.cineview,'servermode'): config.plugins.cineview.servermode=ConfigSelection(default='profile',choices=[('full','Full server details'),('profile','EMU + subscription only (hide server URL)'),('hide','Hide server information')])
    choices=[(k,THEMES[k][0]) for k in ('black','navy','graphite','burgundy','green','purple')]
    if not hasattr(config.plugins.cineview,'theme'): config.plugins.cineview.theme=ConfigSelection(default='black',choices=choices)
    else: config.plugins.cineview.theme.setChoices(choices,default='black')
    if not hasattr(config.plugins.cineview,'weatherprovider'): config.plugins.cineview.weatherprovider=ConfigSelection(default='oa',choices=[('oa','OAWeather (default)'),('msn','WeatherPlugin / MSN Weather')])
    if not hasattr(config.plugins.cineview,'secondtimeout'): config.plugins.cineview.secondtimeout=ConfigSelection(default='20',choices=[('5','5 seconds'),('10','10 seconds'),('15','15 seconds'),('20','20 seconds'),('30','30 seconds'),('60','60 seconds'),('0','No timeout')])
    if not hasattr(config.plugins.cineview,'timeformat'): config.plugins.cineview.timeformat=ConfigSelection(default='24',choices=[('24','24-hour'),('12','12-hour (AM/PM)')])
ensure_config()

def apply_timeout(save=False):
    try:
        if hasattr(config,'usage') and hasattr(config.usage,'show_second_infobar'):
            config.usage.show_second_infobar.value=config.plugins.cineview.secondtimeout.value
            if save: config.usage.show_second_infobar.save()
    except Exception: pass

def apply_time_format(save=False):
    mode=getattr(config.plugins.cineview.timeformat,'value','24')
    try:
        if hasattr(config,'usage') and hasattr(config.usage,'time') and hasattr(config.usage.time,'long'):
            if mode=='12':
                candidates=('%-I:%M:%S%^p','%I:%M:%S%^p','%-I:%M:%S%P','%I:%M:%S%P','%-I:%M:%S','%I:%M:%S')
            else:
                candidates=('%T','%-H:%M:%S')
            choices=[]
            try: choices=[x[0] if isinstance(x,(tuple,list)) else x for x in config.usage.time.long.choices]
            except Exception: pass
            chosen=next((x for x in candidates if not choices or x in choices),candidates[0])
            config.usage.time.long.value=chosen
            if save: config.usage.time.long.save()
    except Exception: pass
    try:
        from .timeformat import apply_timeformat
        apply_timeformat(SKIN_DIR,mode)
    except Exception as e:
        print('[CineView] time format apply failed: %s'%e)

def layout_key(): return '%d%d%d'%(1 if config.plugins.cineview.poster_infobar.value else 0,1 if config.plugins.cineview.poster_second.value else 0,1 if config.plugins.cineview.poster_channels.value else 0)

def effective_weather():
    requested=getattr(config.plugins.cineview.weatherprovider,'value','oa')
    oa=exists_py(OA_SOURCE); msn=exists_py(MSN_SOURCE)
    if requested=='msn' and msn: return 'msn'
    if oa: return 'oa'
    if msn: return 'msn'
    return 'none'

def selected_layout():
    provider=effective_weather()
    if not os.path.exists(POSTERX): return os.path.join(SKIN_DIR,'skin.safe-noposterx-%s.xml'%provider)
    return os.path.join(SKIN_DIR,'skin.layout-%s-%s.xml'%(layout_key(),provider))

def schedule_smartdeps():
    try:
        if os.path.exists(SMARTDEPS):
            # Run after package-manager locks from installation have cleared.
            os.system("(sleep 8; sh '%s' --install) >/tmp/cineview-smartdeps-launch.log 2>&1 &" % SMARTDEPS)
    except Exception:
        pass

class CineViewControlSetup(Screen,ConfigListScreen):
    skin="""<screen name="CineViewControlSetup" position="fill" title="" backgroundColor="steThemePrimary" flags="wfNoBorder">
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CineViewControl/plugin.png" position="112,111" size="261,206" zPosition="2" alphatest="blend" scale="1" />
        <eLabel text="CineView Control" position="425,120" size="1266,65" font="Regular;38" foregroundColor="steThemeAccent" transparent="1" />
        <eLabel text="CineView FHD  •  Designed by habeb-s" position="425,188" size="1266,50" font="Regular;25" foregroundColor="foreground" transparent="1" />
        <widget name="config" position="425,253" size="1304,484" itemHeight="50" font="Regular;27" scrollbarMode="showOnDemand" />
        <widget name="status" position="112,748" size="1624,97" font="Regular;22" valign="center" halign="center" transparent="1" />
        <eLabel text="© 2026 habeb-s  •  CineView FHD  •  Official 2.0" position="112,861" size="1624,40" font="Regular;22" foregroundColor="secondFG" transparent="1" halign="center" />
        <eLabel text="RED  Cancel" position="112,913" size="417,42" font="Regular;25" foregroundColor="#00ff3333" transparent="1" />
        <eLabel text="GREEN  Save" position="1274,913" size="462,42" font="Regular;25" foregroundColor="#0033ff66" transparent="1" halign="right" />
    </screen>"""
    def __init__(self,session):
        Screen.__init__(self,session)
        self.list=[
            getConfigListEntry('Skin color theme',config.plugins.cineview.theme),
            getConfigListEntry('Posters - Main InfoBar',config.plugins.cineview.poster_infobar),
            getConfigListEntry('Posters - Second InfoBar',config.plugins.cineview.poster_second),
            getConfigListEntry('Posters - Channel List',config.plugins.cineview.poster_channels),
            getConfigListEntry('Weather source',config.plugins.cineview.weatherprovider),
            getConfigListEntry('Time format',config.plugins.cineview.timeformat),
            getConfigListEntry('Server / CAM information',config.plugins.cineview.servermode),
            getConfigListEntry('Second InfoBar timeout',config.plugins.cineview.secondtimeout),
        ]
        ConfigListScreen.__init__(self,self.list,session=session)
        self['status']=Label('')
        self['actions']=ActionMap(['OkCancelActions','ColorActions'],{'cancel':self.keyCancel,'red':self.keyCancel,'green':self.keySave,'ok':self.keySave},-2)
        self.onLayoutFinish.append(self.updateStatus)
    def updateStatus(self):
        w=effective_weather(); wname='OAWeather' if w=='oa' else ('WeatherPlugin / MSN' if w=='msn' else 'safe mode (provider missing)')
        self['status'].setText('PosterX: %s   |   Weather: %s   |   CPU sensor: %s\nSmart dependency repair is automatic. Second InfoBar overlay is fixed transparent.'%('INSTALLED' if os.path.exists(POSTERX) else 'AUTO-REPAIR / SAFE MODE',wname,'OK' if os.path.exists(CPU_SENSOR) else 'fallback'))
    def keySave(self):
        if (config.plugins.cineview.poster_infobar.value or config.plugins.cineview.poster_second.value or config.plugins.cineview.poster_channels.value) and not os.path.exists(POSTERX):
            schedule_smartdeps()
        try:
            if config.plugins.cineview.theme.value not in THEMES: config.plugins.cineview.theme.value='black'
            apply_theme(SKIN_DIR,config.plugins.cineview.theme.value)
            src=selected_layout()
            if not os.path.exists(src): raise RuntimeError('layout file missing: %s'%src)
            shutil.copy2(src,ACTIVE); apply_theme(SKIN_DIR,config.plugins.cineview.theme.value); apply_time_format(True)
            for opt in (config.plugins.cineview.theme,config.plugins.cineview.poster_infobar,config.plugins.cineview.poster_second,config.plugins.cineview.poster_channels,config.plugins.cineview.weatherprovider,config.plugins.cineview.timeformat,config.plugins.cineview.servermode,config.plugins.cineview.secondtimeout): opt.save()
            apply_timeout(True); configfile.save()
        except Exception as e:
            self.session.open(MessageBox,'Unable to save CineView settings: %s'%e,MessageBox.TYPE_ERROR,timeout=8); return
        self.session.openWithCallback(self.restartAnswer,MessageBox,'CineView settings saved. Restart Enigma2 GUI now?',MessageBox.TYPE_YESNO)
    def restartAnswer(self,answer):
        if answer:
            try:
                from Screens.Standby import TryQuitMainloop; self.session.open(TryQuitMainloop,3)
            except Exception: os.system('killall -9 enigma2')
        self.close()
    def keyCancel(self): self.close()

def main(session,**kwargs): session.open(CineViewControlSetup)

def sessionstart(reason,session=None,**kwargs):
    if reason==0:
        apply_timeout(False)
        apply_time_format(False)
        try:
            if (not os.path.exists(POSTERX)) or effective_weather()=='none' or not os.path.exists('/usr/bin/bitrate'):
                schedule_smartdeps()
        except Exception:
            pass
        try:
            if hasattr(config.plugins,'bitrate') and hasattr(config.plugins.bitrate,'show_in_menu') and config.plugins.bitrate.show_in_menu.value=='infobar':
                config.plugins.bitrate.show_in_menu.value='extmenu'; config.plugins.bitrate.show_in_menu.save(); configfile.save()
        except Exception: pass

def Plugins(**kwargs):
    return [
        PluginDescriptor(name='CineView Control',description='CineView FHD control center — themes, posters, weather, CPU, CAM privacy and InfoBar settings',where=PluginDescriptor.WHERE_PLUGINMENU,icon='plugin.png',fnc=main),
        PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART,fnc=sessionstart)
    ]

# -*- coding: utf-8 -*-
from __future__ import print_function
import os, re

# Only explicit wall-clock formats are changed. Durations (%S, InMinutes, AsLength)
# and date-only formats stay untouched.
PATTERNS_12_TO_24 = (
    ('%-I:%M:%S%^p', '%H:%M:%S'), ('%I:%M:%S%^p', '%H:%M:%S'),
    ('%-I:%M:%S%P', '%H:%M:%S'), ('%I:%M:%S%P', '%H:%M:%S'),
    ('%-I:%M:%S%p', '%H:%M:%S'), ('%I:%M:%S%p', '%H:%M:%S'),
    ('%-I:%M%^p', '%H:%M'), ('%I:%M%^p', '%H:%M'),
    ('%-I:%M%P', '%H:%M'), ('%I:%M%P', '%H:%M'),
    ('%-I:%M%p', '%H:%M'), ('%I:%M%p', '%H:%M'),
)

def _convert_format(fmt, mode):
    # normalize any CineView 12-hour form back to 24-hour canonical first
    for a,b in PATTERNS_12_TO_24:
        fmt=fmt.replace(a,b)
    fmt=fmt.replace('%-H:%M','%H:%M')
    if mode == '12':
        # Compact AM/PM form fits existing FHD time fields without clipping.
        fmt=fmt.replace('%H:%M:%S','%-I:%M:%S%p')
        fmt=fmt.replace('%H:%M','%-I:%M%p')
    return fmt

def apply_timeformat(skin_dir, mode='24'):
    mode = '12' if str(mode) == '12' else '24'
    changed=0
    rx=re.compile(r'(<convert\s+type="ClockToText">Format:)(.*?)(</convert>)', re.S)
    for root, dirs, files in os.walk(skin_dir):
        for name in files:
            if not name.endswith('.xml'):
                continue
            path=os.path.join(root,name)
            try:
                data=open(path,'r',encoding='utf-8').read()
            except TypeError:
                data=open(path,'r').read()
            def repl(m):
                return m.group(1)+_convert_format(m.group(2),mode)+m.group(3)
            new=rx.sub(repl,data)
            if new != data:
                try:
                    open(path,'w',encoding='utf-8').write(new)
                except TypeError:
                    open(path,'w').write(new)
                changed += 1
    return changed

if __name__ == '__main__':
    import sys
    if len(sys.argv) >= 3:
        apply_timeformat(sys.argv[1], sys.argv[2])

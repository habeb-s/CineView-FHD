# -*- coding: utf-8 -*-
# CineView FHD settings

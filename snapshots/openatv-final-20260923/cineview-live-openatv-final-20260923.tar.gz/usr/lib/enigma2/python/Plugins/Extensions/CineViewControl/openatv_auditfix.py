# -*- coding: utf-8 -*-
from __future__ import print_function
import io,re,sys,xml.etree.ElementTree as ET

def read(p):
    with io.open(p,'r',encoding='utf-8',errors='ignore') as f: return f.read()
def write(p,s):
    with io.open(p,'w',encoding='utf-8') as f: f.write(s)
def sre(name):
    return re.compile(r'(<screen\b(?=[^>]*\bname=["\']'+re.escape(name)+r'["\'])[^>]*>)(.*?)(</screen>)',re.S)

def add_timelines(s,name,y,h):
    m=sre(name).search(s)
    if not m: return s
    body=m.group(2)
    if 'name="timeline0"' not in body:
        block='\n'.join('        <widget name="timeline%d" pixmap="window/timeline.png" position="0,%d" size="1,%d" zPosition="22"/>'%(i,y,h) for i in range(6))
        marker=re.search(r'\s*<widget name="timeline_now"[^>]*/>',body)
        if marker: body=body[:marker.start()]+'\n'+block+'\n'+body[marker.start():]
    body=re.sub(r'<widget name="timeline_now"([^>]*?)position="[^"]+"([^>]*?)/>', lambda mm:'<widget name="timeline_now"'+mm.group(1)+'position="6,%d"'%y+mm.group(2)+' pixmap="window/timeline-now.png" alphatest="blend"/>', body, count=1)
    return s[:m.start()]+m.group(1)+body+m.group(3)+s[m.end():]

def patch_vertical(s,name):
    m=sre(name).search(s)
    if not m: return s
    body=m.group(2); xs=[45,385,725,1065,1405]
    if 'source="piconCh1"' not in body:
        block=[]
        for i,x in enumerate(xs,1):
            block.append('        <widget name="Active%d" position="%d,95" size="330,42" backgroundColor="selectedBG" transparent="0" zPosition="2"/>'%(i,x))
            block.append('        <widget source="piconCh%d" render="Picon" position="%d,95" size="70,42" zPosition="4" alphatest="blend" transparent="1"><convert type="ServiceName">Reference</convert></widget>'%(i,x+5))
        marker=re.search(r'\s*<widget name="currCh1"',body)
        if marker: body=body[:marker.start()]+'\n'+'\n'.join(block)+'\n'+body[marker.start():]
    for i,x in enumerate(xs,1):
        body=re.sub(r'<widget name="currCh%d"[^>]*/>'%i,'<widget name="currCh%d" position="%d,95" size="248,42" font="Regular;27" foregroundColor="secondFG" transparent="1" zPosition="5"/>'%(i,x+82),body,count=1)
    return s[:m.start()]+m.group(1)+body+m.group(3)+s[m.end():]

TASK='''<screen name="TaskView" title="Task View" position="fill" flags="wfNoBorder">
    <panel name="PigTemplate"/>
    <widget source="Title" render="Label" position="780,45" size="1110,48" font="Regular;34" foregroundColor="secondFG" transparent="1"/>
    <widget source="name" render="Label" position="780,120" size="1110,55" font="Regular;34" foregroundColor="foreground" transparent="1"/>
    <widget source="task" render="Label" position="780,185" size="1110,48" font="Regular;29" foregroundColor="grey" transparent="1"/>
    <widget source="progress" render="Progress" position="780,265" size="1110,48" borderWidth="2" backgroundColor="un33333a"/>
    <widget source="progress" render="Label" position="780,267" size="1110,44" font="Regular;31" foregroundColor="foreground" halign="center" valign="center" transparent="1" zPosition="2"><convert type="ProgressToText"/></widget>
    <widget source="status" render="Label" position="780,340" size="1110,48" font="Regular;29" transparent="1"/>
    <widget name="config" position="780,420" size="1110,150" itemHeight="52" font="Regular;29" scrollbarMode="showOnDemand"/>
    <panel name="ButtonTemplate"/>
</screen>'''

def patch_help(s):
    m=sre('HelpMenu').search(s)
    if not m: return s
    old=m.group(0); lm=re.search(r'<widget source="list".*?</widget>',old,re.S)
    listxml=lm.group(0) if lm else '<widget source="list" render="Listbox" position="30,105" size="1100,850" scrollbarMode="showOnDemand"/>'
    listxml=re.sub(r'\sconditional="indicatorU0"','',listxml)
    listxml=re.sub(r'position="[^"]+"','position="30,105"',listxml,count=1)
    listxml=re.sub(r'size="[^"]+"','size="1100,850"',listxml,count=1)
    inds=[]
    for i in range(16):
        for side in ('U','L'):
            inds.append('    <widget name="indicator%s%d" pixmap="yellow_circle23x23.png" position="1450,330" size="23,23" zPosition="20" alphatest="blend"/>'%(side,i))
    new='''<screen name="HelpMenu" title="Help" position="fill" flags="wfNoBorder">
    <panel name="PigLessTemplate"/>
    <widget source="Title" render="Label" position="30,25" size="1830,55" font="Regular;38" foregroundColor="secondFG" transparent="1"/>
    %s
    <widget name="description" position="1165,115" size="695,125" font="Regular;27" foregroundColor="foreground" transparent="1" valign="top"/>
    <widget name="buttonlist" position="1165,250" size="695,80" font="Regular;24" foregroundColor="yellow" transparent="1" valign="top"/>
    <widget name="rc" position="1450,330" size="154,500" zPosition="10" alphatest="blend" transparent="1"/>
    <widget name="label" position="1165,850" size="695,80" font="Regular;23" foregroundColor="secondFG" transparent="1" halign="center" valign="center"/>
%s
    <widget source="key_help" render="Label" position="1690,980" size="170,45" font="Regular;24" foregroundColor="secondFG" halign="center" valign="center" transparent="1"><convert type="ConditionalShowHide"/></widget>
</screen>'''%(listxml,'\n'.join(inds))
    return s[:m.start()]+new+s[m.end():]

def patch(path):
    s=read(path)
    s=s.replace('MultiContentEntryPixmapAlphaBlend(pos=(12, 4), size=(185, 80), png=3, flags=BT_SCALE),','MultiContentEntryPixmapAlphaBlend(pos=(12, 4), size=(185, 80), png=3, flags=BT_SCALE | BT_KEEP_ASPECT_RATIO | BT_HALIGN_CENTER | BT_VALIGN_CENTER),')
    s=add_timelines(s,'GraphicalEPG',385,545)
    s=add_timelines(s,'GraphicalEPGPIG',380,365)
    s=add_timelines(s,'GraphicalInfoBarEPG',112,143)
    s=patch_vertical(s,'EPGvertical'); s=patch_vertical(s,'EPGverticalPIG')
    m=sre('SkinSelection').search(s)
    if m:
        b=m.group(2)
        b=re.sub(r'<widget name="config"[^>]*/>','<widget name="config" position="780,120" size="1080,610" itemHeight="58" font="Regular;30" transparent="1" enableWrapAround="1" scrollbarMode="showOnDemand" zPosition="3"/>',b,count=1)
        b=re.sub(r'<widget name="description"[^>]*/>','<widget name="description" position="780,748" size="1080,110" font="Regular;25" foregroundColor="foreground" transparent="1" valign="top" zPosition="3"/>',b,count=1)
        b=re.sub(r'<widget name="footnote"[^>]*/>','<widget name="footnote" position="780,868" size="1080,55" font="Regular;22" foregroundColor="secondFG" transparent="1" valign="top" zPosition="3"/>',b,count=1)
        s=s[:m.start()]+m.group(1)+b+m.group(3)+s[m.end():]
    if not sre('TaskView').search(s):
        m=sre('JobView').search(s)
        if m: s=s[:m.start()]+TASK+'\n\n'+s[m.start():]
    s=patch_help(s)
    s=s.replace('position="1550,1030" size="540,38"','position="1550,1030" size="340,38"')
    s=s.replace('source="DNS1" render="Label" position="1640,675" size="300,37"','source="DNS1" render="Label" position="1640,675" size="250,37"')
    s=s.replace('source="DNS2" render="Label" position="1640,720" size="300,37"','source="DNS2" render="Label" position="1640,720" size="250,37"')
    s=s.replace('source="session.CurrentService" render="Label" position="450,250" size="1620,800"','source="session.CurrentService" render="Label" position="450,250" size="1420,800"')
    s=s.replace('pixmap="icons/no_coverArt.png"','pixmap="dvr/no_coverArt.png"')
    s=s.replace('pixmap="icons/icon_view.png"','pixmap="/usr/share/enigma2/skin_default/icons/icon_view.png"')
    ET.fromstring(s); write(path,s)
    return True
if __name__=='__main__':
    patch(sys.argv[1]); print('CINEVIEW_OPENATV_AUDITFIX_OK')

#!/bin/sh
# CineView FHD Smart Dependency Doctor. Installs only from the current image's own feed.
PLUGIN=/usr/lib/enigma2/python/Plugins/Extensions/CineViewControl
LOG=${CINEVIEW_LOG:-/tmp/cineview-smartdeps.log}
MODE=${1:---scan}
: > "$LOG"
log(){ echo "[CineView] $*" | tee -a "$LOG"; }
havepy(){ ls "$1".py* >/dev/null 2>&1; }
image_text(){ cat /etc/image-version /etc/issue /etc/os-release /etc/hostname 2>/dev/null | tr 'A-Z' 'a-z'; }
TXT=$(image_text)
case "$TXT" in *openpli*) FAMILY=openpli;; *dreamos*|*dreambox*|*gemini*|*merlin*) FAMILY=dreamos;; *openatv*|*openvix*|*openbh*|*openblackhole*|*opendroid*|*openspa*|*pure2*|*puree2*|*egami*|*teamblue*|*openhdf*|*nonsolosat*|*opentr*|*cobralib*|*satlodge*|*foxbob*|*pkteam*|*hyperion*|*vti*) FAMILY=oealliance;; *) FAMILY=generic;; esac
if command -v opkg >/dev/null 2>&1; then PM=opkg; elif command -v apt-get >/dev/null 2>&1; then PM=apt; else PM=none; fi
log "family=$FAMILY package_manager=$PM"

feed_updated=0
update_feed(){
  [ "$feed_updated" = 1 ] && return 0
  if [ "$PM" = opkg ]; then opkg update >>"$LOG" 2>&1 || true
  elif [ "$PM" = apt ]; then apt-get update >>"$LOG" 2>&1 || true
  fi
  feed_updated=1
}
installed_pkg(){
  p="$1"
  if [ "$PM" = opkg ]; then opkg status "$p" 2>/dev/null | grep -q 'Status:.* installed'
  elif [ "$PM" = apt ]; then dpkg-query -W -f='${Status}' "$p" 2>/dev/null | grep -q 'install ok installed'
  else return 1; fi
}
feed_has(){
  p="$1"
  if [ "$PM" = opkg ]; then opkg list 2>/dev/null | grep -q "^${p} -"
  elif [ "$PM" = apt ]; then apt-cache show "$p" >/dev/null 2>&1
  else return 1; fi
}
install_exact(){
  p="$1"; installed_pkg "$p" && return 0
  [ "$MODE" = --install ] || return 1
  update_feed
  feed_has "$p" || return 1
  log "installing $p"
  if [ "$PM" = opkg ]; then opkg install "$p" >>"$LOG" 2>&1
  else DEBIAN_FRONTEND=noninteractive apt-get -y install "$p" >>"$LOG" 2>&1; fi
}
install_first(){
  for p in "$@"; do install_exact "$p" && return 0; done
  return 1
}
install_search(){
  pat="$1"; [ "$MODE" = --install ] || return 1; update_feed
  if [ "$PM" = opkg ]; then p=$(opkg list 2>/dev/null | grep -i "$pat" | head -n 1 | cut -d' ' -f1)
  elif [ "$PM" = apt ]; then p=$(apt-cache search "$pat" 2>/dev/null | awk 'NR==1{print $1}')
  fi
  [ -n "$p" ] && install_exact "$p"
}

# PosterX: CineView ships CineViewPosterX under a unique name; do not alter image PosterX packages.
log 'CineViewPosterX=BUILTIN'

# Weather: install the image-native provider first. On OpenPLi prefer WeatherPlugin.
if havepy /usr/lib/enigma2/python/Components/Sources/OAWeather; then log 'OAWeather=OK'; else
  if [ "$FAMILY" != openpli ]; then install_first enigma2-plugin-extensions-oaweather oaweather || true; fi
fi
if havepy /usr/lib/enigma2/python/Components/Sources/MSNWeather; then log 'WeatherPlugin=OK'; else
  install_first enigma2-plugin-extensions-weatherplugin weatherplugin || true
fi
if havepy /usr/lib/enigma2/python/Components/Sources/OAWeather || havepy /usr/lib/enigma2/python/Components/Sources/MSNWeather; then log 'Weather=OK'; else log 'Weather=SAFE-FALLBACK'; fi

# Bitrate binary used by CineViewBitrate.
if command -v bitrate >/dev/null 2>&1; then log 'Bitrate=OK'; else
  install_first enigma2-plugin-extensions-bitrate bitrate || install_search 'enigma2-plugin.*bitrate'
  command -v bitrate >/dev/null 2>&1 && log 'Bitrate=INSTALLED' || log 'Bitrate=UNAVAILABLE'
fi

# Requests is used by the built-in IMDb reader; IMDb plugin itself is optional.
if command -v python3 >/dev/null 2>&1; then install_first python3-requests python3-requests-cache || true
else install_first python-requests python-requests-cache || true; fi

# Official IMDb plugin is useful when available but not required for the CineView rating converter.
install_first enigma2-plugin-extensions-imdb imdb || true

# Re-evaluate and activate the safest matching layout after any installation attempt.
[ -x "$PLUGIN/activate.sh" ] && "$PLUGIN/activate.sh" >>"$LOG" 2>&1 || true
log 'dependency scan complete'
exit 0

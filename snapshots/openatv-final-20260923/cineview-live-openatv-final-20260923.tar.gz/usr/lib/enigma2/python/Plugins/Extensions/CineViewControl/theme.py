# -*- coding: utf-8 -*-
from __future__ import print_function
import os, re, sys, shutil
THEMES = {
    'black': ('Black', '#000000'),
    'navy': ('Dark Navy', '#0A1D35'),
    'graphite': ('Graphite', '#292D32'),
    'burgundy': ('Burgundy', '#501C2C'),
    'green': ('Dark Green', '#153B2B'),
    'purple': ('Deep Purple', '#38204F'),
}
def _rgb(h):
    h=h.lstrip('#'); return tuple(int(h[i:i+2],16) for i in (0,2,4))
def _mix(a,b,t): return tuple(round(a[i]*(1-t)+b[i]*t) for i in range(3))
def _hx(c, alpha=0): return '#%02X%02X%02X%02X' % (alpha,c[0],c[1],c[2])
def palette(key):
    if key not in THEMES: key='black'
    base=_rgb(THEMES[key][1]); black=(0,0,0); white=(255,255,255)
    if key=='black':
        return {'steThemePrimary':'#00000000','steThemePanel':'#00101214','steThemePanelAlt':'#00242424','steThemeTop':'#000D0F16','steThemeOverlay':'#2D101214','steThemeOverlayStrong':'#54101214','steThemeSelected':'#06303240','steThemeText':'#00F0F0F0','steThemeMuted':'#00B6B6B6','steThemeAccent':'#00F9C731','steSecondInfoBG':_hx(base,0x78)}
    panel=_mix(base,black,0.18); panel_alt=_mix(base,black,0.34); top=_mix(base,black,0.42); selected=_mix(base,white,0.16)
    return {'steThemePrimary':_hx(base,0),'steThemePanel':_hx(panel,0),'steThemePanelAlt':_hx(panel_alt,0),'steThemeTop':_hx(top,0),'steThemeOverlay':_hx(panel,0x2D),'steThemeOverlayStrong':_hx(panel_alt,0x54),'steThemeSelected':_hx(selected,0x06),'steThemeText':'#00F0F0F0','steThemeMuted':'#00B6B6B6','steThemeAccent':'#00F9C731','steSecondInfoBG':_hx(base,0x78)}
def apply_theme_to_xml(path,key):
    if not os.path.exists(path): return False
    data=open(path).read(); pal=palette(key)
    for name,val in pal.items():
        pat=r'(<color\s+name=["\']'+re.escape(name)+r'["\']\s+value=["\'])#[0-9A-Fa-f]{8}(["\'])'
        data,n=re.subn(pat,lambda m:m.group(1)+val+m.group(2),data,count=1)
        if n!=1: raise RuntimeError('theme color missing: %s in %s'%(name,path))
    open(path,'w').write(data); return True
def apply_assets(skin_dir,key):
    src=os.path.join(skin_dir,'themes',key)
    for rel in ('infobar/hd.png','infobar/bl80.png','extensions/transblack.png'):
        f=os.path.join(src,rel)
        if os.path.exists(f):
            dst=os.path.join(skin_dir,rel); 
            d=os.path.dirname(dst)
            if not os.path.isdir(d):
                try: os.makedirs(d)
                except OSError: pass
            shutil.copy2(f,dst)
def apply_theme(skin_dir,key):
    if key not in THEMES: key='black'
    names=['skin.xml','skin.withposters.xml','skin.noposters.xml','skin.safe-noposterx.xml']
    for a,b,c in __import__('itertools').product((0,1),repeat=3):
        for provider in ('oa','msn','none'):
            names.append('skin.layout-%s%s%s-%s.xml'%(a,b,c,provider))
    names += ['skin.safe-noposterx-oa.xml','skin.safe-noposterx-msn.xml','skin.safe-noposterx-none.xml']
    for name in names:
        p=os.path.join(skin_dir,name)
        if os.path.exists(p): apply_theme_to_xml(p,key)
    apply_assets(skin_dir,key); return key
if __name__=='__main__':
    skin=sys.argv[1] if len(sys.argv)>1 else '/usr/share/enigma2/CineView_FHD'
    key=sys.argv[2] if len(sys.argv)>2 else 'black'
    print(apply_theme(skin,key))

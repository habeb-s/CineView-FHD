#!/bin/sh
SKIN=/usr/share/enigma2/CineView_FHD
PLUGIN=/usr/lib/enigma2/python/Plugins/Extensions/CineViewControl
SETTINGS=/etc/enigma2/settings
[ -f "$SETTINGS" ] || touch "$SETTINGS"
get_key(){ grep "^$1=" "$SETTINGS" 2>/dev/null | tail -1 | cut -d= -f2-; }
set_key(){ key="$1"; val="$2"; if grep -q "^${key}=" "$SETTINGS" 2>/dev/null; then sed -i "s|^${key}=.*|${key}=${val}|" "$SETTINGS"; else echo "${key}=${val}" >> "$SETTINGS"; fi; }
have(){ ls "$1".py* >/dev/null 2>&1; }
bool_digit(){ case "$1" in False|false|0|no|No) echo 0;; *) echo 1;; esac; }
I=$(bool_digit "$(get_key config.plugins.cineview.poster_infobar)")
S=$(bool_digit "$(get_key config.plugins.cineview.poster_second)")
C=$(bool_digit "$(get_key config.plugins.cineview.poster_channels)")
REQ=$(get_key config.plugins.cineview.weatherprovider); [ -n "$REQ" ] || REQ=oa
OA=0; MSN=0
have /usr/lib/enigma2/python/Components/Sources/OAWeather && have /usr/lib/enigma2/python/Components/Converter/OAWeather && OA=1
have /usr/lib/enigma2/python/Components/Sources/MSNWeather && have /usr/lib/enigma2/python/Components/Converter/MSNWeather && MSN=1
if [ "$REQ" = msn ] && [ "$MSN" = 1 ]; then W=msn; elif [ "$OA" = 1 ]; then W=oa; elif [ "$MSN" = 1 ]; then W=msn; else W=none; fi
if have /usr/lib/enigma2/python/Components/Renderer/CineViewPosterX; then SRC="$SKIN/skin.layout-${I}${S}${C}-${W}.xml"; else SRC="$SKIN/skin.safe-noposterx-${W}.xml"; fi
[ -f "$SRC" ] || SRC="$SKIN/skin.layout-000-${W}.xml"
[ -f "$SRC" ] || SRC="$SKIN/skin.layout-000-none.xml"
cp -f "$SRC" "$SKIN/skin.xml"
THEME=$(get_key config.plugins.cineview.theme); case "$THEME" in black|navy|graphite|burgundy|green|purple) ;; *) THEME=black;; esac
PY=python3; command -v "$PY" >/dev/null 2>&1 || PY=python
"$PY" "$PLUGIN/theme.py" "$SKIN" "$THEME" >/dev/null 2>&1 || true
FMT=$(get_key config.plugins.cineview.timeformat); [ "$FMT" = 12 ] || FMT=24
"$PY" "$PLUGIN/timeformat.py" "$SKIN" "$FMT" >/dev/null 2>&1 || true
"$PY" "$PLUGIN/compat.py" "$SKIN" /usr/lib/enigma2/python /tmp/cineview-compat-report.json >/dev/null 2>&1 || true
"$PY" "$PLUGIN/openatv_v5.py" "$SKIN/skin.xml" >/dev/null 2>&1 || true
"$PY" "$PLUGIN/openatv_auditfix.py" "$SKIN/skin.xml" >/dev/null 2>&1 || true
exit 0
